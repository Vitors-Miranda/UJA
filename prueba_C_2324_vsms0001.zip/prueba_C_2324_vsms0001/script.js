const form = document.getElementById("form")
const results = document.getElementById("ul-results")

// SUBMIT
form.addEventListener("submit", (e) => {
    e.preventDefault()

    let data = new FormData(e.target)
    enviaCoeficientes(data)

})

function enviaCoeficientes(data){

    // JSON
    let json = {
        "a" : Number(data.get("a")),
        "b" : Number(data.get("b")),
        "c" : Number(data.get("c")),
    }

    // REQUEST
    var xhttp = new XMLHttpRequest();
    xhttp.open("POST", "http://labtelema.ujaen.es:8083/sqrt");
    xhttp.setRequestHeader("Content-Type","application/json")
    xhttp.send(JSON.stringify(json))
    xhttp.onload = function() {

        // SI HAY UN ERROR

        if (xhttp.status != 200) { 
          alert(`Error ${xhttp.status}: ${xhttp.statusText}`); 

        // SI ESTA BIEN

        } else{
            // RECUPERANDO LOS VALORES
            let x1 = JSON.parse(xhttp.response).x1
            let x2 = JSON.parse(xhttp.response).x2
            let b,c

            // ANADINDO EL + EN LA FRENTE DEL NÚMERO
            b = Number(data.get("b")) > -1 ? " + " +  data.get("b") : data.get("b")
            c = Number(data.get("c")) > -1 ? " + " +  data.get("c") : data.get("c")

            // EL OPERADOR TERNÁRIO (? y :) ESCONDE SI ES "A" o "B" 1,  O SI "C" ES "0"
            // uSÉ H2 AO INVÉS DE STRONG PARA LA ECUACIÓN FICAR MAYOR
            results.innerHTML = `
            <li><h2>${data.get("a") == 1 ? "" : data.get("a") == 0 ? "" : data.get("a")} x^2 ${data.get("b") == 1 ? " + x" : data.get("b") == 0 ? "" : b + "x"}   ${data.get("c") == 0 ? "" : c} </h2> </li>
            <li> <em> X1 = ${x1} <br> </em></li>
            <li> <em>X2 = ${x2}  </em></li>

            `
        }
    }
}